msg = "hello world!"
print(msg)

